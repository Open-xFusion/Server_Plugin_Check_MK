Server_Management_Plugin_Check_MK
Check_MK Plugin Pack for XFUSION Server

I. General Information

Name:     Check_MK Plugin for XFUSION Server
Category: Monitoring
Version:  2.2.0
II. Description

This is a check_MK plugin for monitoring XFUSION Server 
III.Supported Software Version

 Check_MK 1.6, 2.0
IV.Software Requirements

Python 2.7.13, 3.7.5   
pysnmp-4.2.4  
pyasn1-0.1.6    
pycrypto-2.3
V.Supported Device

XFUSION Rack Server:         RH2288H V2, RH1288 V3, RH2288 V3, RH2288H V3, RH5885 V3, RH8100 V3, 1288H V5, 2288H V5, 2488 V5, 1288H V6, 2288H V6   
XFUSION High-density Server: XH321 V3, XH620 V3, XH622 V3, XH628 V3